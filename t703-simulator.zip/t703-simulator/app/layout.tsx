import "./globals.css";
export const metadata={title:"T-703 Operation Simulator",description:"Simplified training PFD"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="vi"><body>{children}</body></html>}