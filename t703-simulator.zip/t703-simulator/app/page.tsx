"use client";
import {useEffect,useMemo,useState} from "react";
import Pfd from "@/components/Pfd";
import {STEPS} from "@/data/steps";
export type SimState={running:boolean;paused:boolean;step:number;tk:number;d701:number;t703:number;d702:number;d711:number;pressure:number;temp:number;reflux:number;feed:number;bottom:number;alarms:string[]};
const initial:SimState={running:false,paused:false,step:0,tk:70,d701:5,t703:10,d702:20,d711:5,pressure:.2,temp:35,reflux:0,feed:0,bottom:0,alarms:[]};
export default function Home(){
 const [s,setS]=useState(initial); const [selected,setSelected]=useState("T-703"); const step=STEPS[s.step];
 useEffect(()=>{if(!s.running||s.paused)return; const id=setInterval(()=>setS(x=>{
  let n={...x,alarms:[] as string[]};
  if(x.step>=2){n.feed=Math.min(10,x.feed+.2);n.tk=Math.max(0,x.tk-.04);n.d701=Math.min(80,x.d701+.03)}
  if(x.step>=3){n.t703=Math.min(60,x.t703+.025);n.temp=Math.min(130,x.temp+.25);n.pressure=Math.min(4.8,x.pressure+.006)}
  if(x.step>=4){n.reflux=Math.min(3,x.reflux+.1);n.d702=Math.min(70,x.d702+.02)}
  if(x.step>=5){n.bottom=Math.min(7,x.bottom+.12);n.d711=Math.min(55,x.d711+.02)}
  if(n.pressure>3.9)n.alarms.push("PAH: T-703 HIGH PRESSURE"); if(n.t703>50)n.alarms.push("LAH: T-703 HIGH LEVEL"); if(n.d711>40)n.alarms.push("LAH: D-711 HIGH LEVEL");
  return n}),500);return()=>clearInterval(id)},[s.running,s.paused]);
 const advance=()=>setS(x=>({...x,running:true,paused:false,step:Math.min(STEPS.length-1,x.step+1)}));
 const reset=()=>setS(initial);
 return <main><header><div><h1>T-703 START-UP SIMULATOR</h1><p>PFD đào tạo tương tác • Không thay thế SOP/P&amp;ID đã phê duyệt</p></div><div className="actions"><button onClick={()=>setS(x=>({...x,running:true,paused:false}))}>▶ Start</button><button onClick={()=>setS(x=>({...x,paused:!x.paused}))}>⏸ Pause</button><button onClick={reset}>↻ Reset</button></div></header>
 <section className="layout"><div className="main"><Pfd s={s} selected={selected} onSelect={setSelected}/><div className="alarms">{s.alarms.length?s.alarms.map(a=><b key={a}>⚠ {a}</b>):<span>✓ No active alarm</span>}</div></div>
 <aside><small>PHASE {s.step+1}/{STEPS.length}</small><h2>{step.title}</h2><p>{step.action}</p><div className="check">{step.checks.map(c=><label key={c}><input type="checkbox"/> {c}</label>)}</div><button className="next" onClick={advance} disabled={s.step===STEPS.length-1}>Confirm &amp; Next</button><hr/><h3>Selected: {selected}</h3><Metric name="PIC-721" value={s.pressure.toFixed(2)} unit="kg/cm²g"/><Metric name="LIC-721" value={s.t703.toFixed(0)} unit="%"/><Metric name="TI-721" value={s.temp.toFixed(0)} unit="°C"/><Metric name="FIC-712" value={s.feed.toFixed(1)} unit="t/h"/><Metric name="FIC-736" value={s.reflux.toFixed(1)} unit="t/h"/><Metric name="FIC-722" value={s.bottom.toFixed(1)} unit="t/h"/></aside></section></main>}
function Metric({name,value,unit}:{name:string,value:string,unit:string}){return <div className="metric"><span>{name}</span><strong>{value} <i>{unit}</i></strong></div>}
