# T-703 Operation Simulator

Simplified interactive training PFD built with Next.js 15 and SVG.

## Run
```bash
npm install
npm run dev
```
Open http://localhost:3000.

## Deploy to Vercel
Push this folder to a private GitHub repository, import it in Vercel, and keep the default Next.js build settings.

## Safety
Training simulation only. Do not use this project as an operating instruction. Always follow the approved SOP, P&ID, permit, interlocks, and supervisor direction. Do not publish confidential plant documents.
