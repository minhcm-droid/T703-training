export const STEPS=[
{title:"Preparation",action:"Xác nhận utility, nitrogen purge, seal/flushing, PSV lineup và ESD reset.",checks:["CW/IA/PA/N₂ available","Seal & flushing normal","No major leakage"]},
{title:"Warm-up",action:"Drain condensate trước khi cấp steam. Warm-up E-711, D-711 và tracing từ từ.",checks:["Steam trap lined up","No water hammer","Temperature rising steadily"]},
{title:"Feed TK-703 → D-701",action:"Prime P-703, mở suction, vent khí, sau đó start bơm và tăng FIC-713.",checks:["P-703 primed","Suction open","Discharge pressure normal"]},
{title:"Feed D-701 → T-703",action:"Start P-702A, tăng FIC-712 đến 10 t/h và theo dõi mức T-703.",checks:["D-701 level adequate","P-702A normal","No leakage"]},
{title:"Reflux & Reboiler",action:"Start reflux, circulation P-705/E-703 và tăng MS từ từ. Theo dõi PIC-721, LIC-721, PDI-732.",checks:["Reflux established","Condensate draining","Pressure controlled"]},
{title:"Feed to D-711",action:"Start P-711, warm E-711 bằng HS và tăng FIC-722 đến 7 t/h khi D-711 đủ nhiệt.",checks:["E-711 warm","D-711 ready","PIC-723 stable"]},
{title:"Stable operation",action:"Xác nhận áp suất, mức, nhiệt độ và lưu lượng ổn định; không còn alarm chưa xử lý.",checks:["PIC-721 stable","LIC-721 30–40%","No active alarm"]}
];